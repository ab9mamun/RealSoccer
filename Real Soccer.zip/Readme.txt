Run the app:
	Run the Real Soccer.jar file and hit (i) button.. See the instructions and faq page for help.



Important: 
	Install the fonts from the Fonts directory.
	If java is not installed in your pc, go download jdk 8 or later.


To change port count, you may try hitting F10





Report bugs/any suggestion: ab9mamun@gmail.com

jdk download

http://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html